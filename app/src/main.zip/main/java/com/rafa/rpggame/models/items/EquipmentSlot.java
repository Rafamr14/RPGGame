package com.rafa.rpggame.models.items;

public enum EquipmentSlot {
    HEAD, CHEST, LEGS, FEET, HANDS, MAIN_HAND, OFF_HAND, NECK, RING1, RING2
}