package com.rafa.rpggame.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.rafa.rpggame.R;
import com.rafa.rpggame.adapters.CharacterAdapter;
import com.rafa.rpggame.adapters.ZoneAdapter;
import com.rafa.rpggame.dialogs.ExplorationResultDialog;
import com.rafa.rpggame.managers.UserAccountManager;
import com.rafa.rpggame.managers.ZoneManager;
import com.rafa.rpggame.models.UserAccount;
import com.rafa.rpggame.models.character.Character;
import com.rafa.rpggame.models.zones.Exploration;
import com.rafa.rpggame.models.zones.Zone;
import java.util.List;

public class ExploreActivity extends AppCompatActivity {
    private UserAccount userAccount;
    private Character selectedCharacter;

    private TextView characterInfoText;
    private TextView staminaText;
    private Spinner zoneSpinner;
    private ListView characterListView;
    private Button exploreButton;
    private CharacterAdapter characterAdapter;
    private ZoneAdapter zoneAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        // Obtener datos
        userAccount = UserAccountManager.getCurrentAccount();
        selectedCharacter = userAccount.getSelectedCharacter();

        // Inicializar vistas
        characterInfoText = findViewById(R.id.character_info_text);
        staminaText = findViewById(R.id.stamina_text);
        zoneSpinner = findViewById(R.id.zone_spinner);
        characterListView = findViewById(R.id.character_list_view);
        exploreButton = findViewById(R.id.explore_button);

        // Configurar adaptadores
        characterAdapter = new CharacterAdapter(this, userAccount.getCharacters());
        characterListView.setAdapter(characterAdapter);

        List<Zone> availableZones = ZoneManager.getAvailableZones(selectedCharacter.getLevel());
        zoneAdapter = new ZoneAdapter(this, availableZones);
        zoneSpinner.setAdapter(zoneAdapter);

        // Seleccionar personaje actual en la lista
        int selectedPosition = userAccount.getCharacters().indexOf(selectedCharacter);
        characterListView.setItemChecked(selectedPosition, true);

        // Eventos
        characterListView.setOnItemClickListener((parent, view, position, id) -> {
            selectedCharacter = userAccount.getCharacters().get(position);
            userAccount.setSelectedCharacter(selectedCharacter);
            updateUI();

            // Actualizar lista de zonas disponibles según nivel del personaje
            List<Zone> zones = ZoneManager.getAvailableZones(selectedCharacter.getLevel());
            zoneAdapter = new ZoneAdapter(ExploreActivity.this, zones);
            zoneSpinner.setAdapter(zoneAdapter);
        });

        exploreButton.setOnClickListener(v -> {
            Zone selectedZone = (Zone) zoneSpinner.getSelectedItem();

            if (selectedZone == null) {
                showMessage("Selecciona una zona para explorar");
                return;
            }

            if (selectedCharacter.getLevel() < selectedZone.getMinLevel()) {
                showMessage("Nivel insuficiente para explorar esta zona");
                return;
            }

            if (userAccount.getStamina() < selectedZone.getStaminaCost()) {
                showMessage("No tienes suficiente stamina");
                return;
            }

            // Iniciar exploración
            startExploration(selectedZone);
        });

        updateUI();
    }

    private void updateUI() {
        characterInfoText.setText(selectedCharacter.getName() + " - Nivel " + selectedCharacter.getLevel());
        staminaText.setText("Stamina: " + userAccount.getStamina() + "/" + userAccount.getMaxStamina());
    }

    private void startExploration(Zone zone) {
        Exploration exploration = zone.startExploration(selectedCharacter, userAccount);

        if (exploration != null) {
            // Mostrar diálogo de resultados
            ExplorationResultDialog dialog = new ExplorationResultDialog(exploration);
            dialog.show(getSupportFragmentManager(), "exploration_result");

            // Actualizar UI
            updateUI();

            // Guardar cambios en la cuenta
            UserAccountManager.updateAccount();
        } else {
            showMessage("No se pudo iniciar la exploración");
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}