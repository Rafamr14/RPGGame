package com.rafa.rpggame.models.zones;

public enum ExplorationType {
    NORMAL,  // Exploración estándar
    BOSS,    // Encuentro con jefe
    EVENT    // Evento especial
}