package com.rafa.rpggame.models.character;

public enum CharacterRole {
    TANK,
    HEALER,
    DPS,
    SUPPORT
}