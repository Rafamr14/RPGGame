package com.rafa.rpggame.models.character;

public enum Stat {
    STRENGTH,
    DEFENSE,
    AGILITY,
    INTELLIGENCE,
    MAX_HP,
    CURRENT_HP,
    ATTACK_POWER,
    MAGIC_POWER,
    CRITICAL_CHANCE
}